import "./FollowUs.css";

const XIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
);

const FacebookIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0 0 22 12z" />
  </svg>
);

const InstagramIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
  </svg>
);

const YouTubeIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
  </svg>
);

const FollowUs = () => {
  return (
    <section className="follow-us">
      <img src="/MainLogo2.jpeg" alt="Cabby Sports" className="follow-us__logo" />

      <div className="follow-us__text">
        <h4 className="follow-us__title">Enjoyed this story? Follow Cabby Sports</h4>
        <p className="follow-us__tagline">Improved Dynamics of Sports</p>

        <div className="follow-us__links">
          <a
            href="https://x.com/cabbysports_1"
            target="_blank"
            rel="noopener noreferrer"
            className="follow-us__btn follow-us__btn--x"
          >
            <XIcon /> Follow on X
          </a>

          <a
            href="https://www.facebook.com/profile.php?id=100091353158880"
            target="_blank"
            rel="noopener noreferrer"
            className="follow-us__btn follow-us__btn--fb"
          >
            <FacebookIcon /> Follow on Facebook
          </a>

                  <a
            href="https://www.instagram.com/cabby_sports/?__pwa=1"
            target="_blank"
            rel="noopener noreferrer"
            className="follow-us__btn follow-us__btn--ig"
          >
            <InstagramIcon /> Follow on Instagram
          </a>

          <a
            href="https://youtube.com/@cabbysports1?si=jpwJb2hEfXAGosO7"
            target="_blank"
            rel="noopener noreferrer"
            className="follow-us__btn follow-us__btn--yt"
          >
            <YouTubeIcon /> Subscribe on YouTube
          </a>

        </div>
      </div>
    </section>
  );
};

export default FollowUs;