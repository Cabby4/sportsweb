import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getFixtureById } from "../services/api";

const MatchDetails = () => {
  const { id } = useParams();

  const [fixture, setFixture] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchFixture = async () => {
      try {
        const data = await getFixtureById(id);
        setFixture(data.data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchFixture();
  }, [id]);

  if (loading) {
    return (
      <div className="container py-5 text-center">
        <h4>Loading match...</h4>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container py-5 text-center">
        <h4 className="text-danger">{error}</h4>

        <Link to="/fixtures" className="btn btn-dark mt-3">
          Back to Fixtures
        </Link>
      </div>
    );
  }

  if (!fixture) {
    return (
      <div className="container py-5 text-center">
        <h4>Match not found</h4>

        <Link to="/fixtures" className="btn btn-dark mt-3">
          Back to Fixtures
        </Link>
      </div>
    );
  }

  return (
    <div className="container py-5">

      <Link to="/fixtures" className="btn btn-outline-dark mb-4">
        ← Back to Fixtures
      </Link>

      <div className="card border-0 shadow-sm">

        <div className="card-body p-4 p-md-5">

          {/* Competition */}
          <div className="text-center mb-4">

            <span className="badge bg-success px-3 py-2">
              {fixture.competition}
            </span>

            {fixture.matchweek && (
              <p className="text-muted mt-2 mb-0">
                Matchweek {fixture.matchweek}
              </p>
            )}

          </div>

          {/* Teams */}
          <div className="row align-items-center text-center">

            {/* Home Team */}
            <div className="col-5">

              {fixture.homeTeam?.logo && (
                <img
                  src={fixture.homeTeam.logo}
                  alt={fixture.homeTeam.name}
                  style={{
                    width: "130px",
                    height: "130px",
                    objectFit: "contain",
                  }}
                />
              )}

              <h2 className="fw-bold mt-3">
                {fixture.homeTeam?.name || "Home Team"}
              </h2>

              <p className="text-muted">
                {fixture.homeTeam?.shortName || ""}
              </p>

            </div>

            {/* VS */}
            <div className="col-2">

              <div className="display-6 fw-bold text-muted">
                VS
              </div>

            </div>

            {/* Away Team */}
            <div className="col-5">

              {fixture.awayTeam?.logo && (
                <img
                  src={fixture.awayTeam.logo}
                  alt={fixture.awayTeam.name}
                  style={{
                    width: "130px",
                    height: "130px",
                    objectFit: "contain",
                  }}
                />
              )}

              <h2 className="fw-bold mt-3">
                {fixture.awayTeam?.name || "Away Team"}
              </h2>

              <p className="text-muted">
                {fixture.awayTeam?.shortName || ""}
              </p>

            </div>

          </div>

          <hr className="my-4" />

          {/* Match Information */}
          <div className="row text-center">

            <div className="col-md-4 mb-3">

              <h6 className="fw-bold">
                Date & Time
              </h6>

              <p className="text-muted mb-0">
                {new Date(
                  fixture.matchDate
                ).toLocaleString()}
              </p>

            </div>

            <div className="col-md-4 mb-3">

              <h6 className="fw-bold">
                Venue
              </h6>

              <p className="text-muted mb-0">
                {fixture.venue || "Venue not available"}
              </p>

            </div>

            <div className="col-md-4 mb-3">

              <h6 className="fw-bold">
                Status
              </h6>

              <span className="badge bg-success">
                {fixture.status}
              </span>

            </div>

          </div>

          {/* Description */}
          {fixture.description && (
            <div className="mt-4 pt-4 border-top">

              <h5 className="fw-bold">
                Match Preview
              </h5>

              <p className="text-muted">
                {fixture.description}
              </p>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};

export default MatchDetails;